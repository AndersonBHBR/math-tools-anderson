from setuptools import setup, find_packages

setup(
    name="math_tools_anderson",
    version="0.1.0",
    description="Pacote simples de operações matemáticas",
    author="Seu Nome",
    author_email="seuemail@example.com",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
