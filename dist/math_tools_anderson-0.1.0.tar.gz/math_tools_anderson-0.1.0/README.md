# Math Tools

Pacote simples com funções matemáticas como soma e subtração.

## Instalação

```bash
pip install math-tools
```

## Uso

```python
from math_tools.math_utils import add

print(add(2, 3))  # Output: 5
```
